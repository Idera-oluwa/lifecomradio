const items = [
    {
      title: 'How can I listen to Lifecom Radio?',
      content: 'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Sed vestibulum nisi id turpis fermentum, sit amet faucibus justo dapibus. Nullam malesuada, ipsum nec dictum fermentum, justo nunc sodales mauris, vitae vulputate ipsum risus quis magna. Phasellus feugiat elit sit amet diam aliquam, sit amet tincidunt eros fermentum.',
    },
    {
      title: 'Is Lifecom Radio available on mobile devices?',
      content: 'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Sed vestibulum nisi id turpis fermentum, sit amet faucibus justo dapibus. Nullam malesuada, ipsum nec dictum fermentum, justo nunc sodales mauris, vitae vulputate ipsum risus quis magna. Phasellus feugiat elit sit amet diam aliquam, sit amet tincidunt eros fermentum.',
    },
    {
      title: 'Does Lifecom Radio offer advertisement opportunities?',
      content: 'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Sed vestibulum nisi id turpis fermentum, sit amet faucibus justo dapibus. Nullam malesuada, ipsum nec dictum fermentum, justo nunc sodales mauris, vitae vulputate ipsum risus quis magna. Phasellus feugiat elit sit amet diam aliquam, sit amet tincidunt eros fermentum.',
    },
    {
        title: 'How can I contact Lifecom Radio for further assistance?',
        content: 'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Sed vestibulum nisi id turpis fermentum, sit amet faucibus justo dapibus. Nullam malesuada, ipsum nec dictum fermentum, justo nunc sodales mauris, vitae vulputate ipsum risus quis magna. Phasellus feugiat elit sit amet diam aliquam, sit amet tincidunt eros fermentum.',
      },
  ];

  export default items