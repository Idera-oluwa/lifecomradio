exports.id=413,exports.ids=[413],exports.modules={2746:e=>{"use strict";e.exports={locales:["en","fr","es","it"],defaultLocale:"en"}},1732:(e,t,s)=>{"use strict";s.a(e,async(e,r)=>{try{s.d(t,{Z:()=>m});var a=s(997),l=s(6689),i=s(1664),n=s.n(i),o=s(9332),c=s(8986);s(1163);var x=s(7987),d=e([c,x]);[c,x]=d.then?(await d)():d;let m=({locale:e})=>{let{t}=(0,x.useTranslation)("subscribe",{lng:e}),s=(0,o.usePathname)();"en"===e||s.substring(3);let[r,i]=(0,l.useState)(t("Subscribe to get more info")),[c,d]=(0,l.useState)(t("At LifeCom Radio, we believe in providing more than just music and podcasts; we're dedicated to fostering a vibrant community of learning and growth.")),[m,p]=(0,l.useState)(t("Email address")),[h,u]=(0,l.useState)(t("Home")),[g,f]=(0,l.useState)(t("Explore")),[j,w]=(0,l.useState)(t("Schedule")),[b,v]=(0,l.useState)(t("About us")),[C,N]=(0,l.useState)(t("Contact"));return(0,a.jsxs)("div",{className:"hidden md:block mt-[12rem] bg-[#09172E] w-full pt-[3rem]",children:[(0,a.jsxs)("div",{className:"w-[90vw] mx-auto flex flex-row justify-between pb-[4rem]",children:[(0,a.jsxs)("div",{children:[a.jsx("img",{src:"/images/home/logo.svg",alt:"",className:"w-[96px] h-[96px]"}),(0,a.jsxs)("div",{className:"flex flex-row gap-[0.5rem] mt-[2rem]",children:[a.jsx("a",{href:"https://www.facebook.com/Lifecomfm.co.uk/",target:"_blank",rel:"noreferrer",children:a.jsx("img",{src:"/images/home/facebook.svg",alt:""})}),a.jsx("img",{src:"/images/home/twitter.svg",alt:""}),a.jsx("a",{href:"https://www.instagram.com/lifecom_radioandtelevision/",target:"_blank",rel:"noreferrer",children:a.jsx("img",{src:"/images/home/instagram.svg",alt:""})}),a.jsx("img",{src:"/images/home/linkedin.svg",alt:""})]})]}),(0,a.jsxs)("div",{children:[(0,a.jsxs)("ul",{className:"flex flex-row gap-[1.5rem] items-center",children:[a.jsx(n(),{href:"/",children:a.jsx("li",{className:`font-normal text-[16px] leading-[19px] cursor-pointer hover:text-[#145C9B] ${"/"===s||3===s.length?"text-[#145C9B]":"bg-transparent text-white "}
      `,children:h})}),a.jsx(n(),{href:"/explore",children:a.jsx("li",{className:`font-normal text-[16px] leading-[19px] cursor-pointer hover:text-[#145C9B]
               ${s.startsWith("/explore")?"text-[#145C9B]":"bg-transparent text-white "}`,children:g})}),a.jsx(n(),{href:"/schedule",children:a.jsx("li",{className:`font-normal text-[16px] leading-[19px] cursor-pointer  hover:text-[#145C9B] ${"/schedule"===s?"text-[#145C9B]":"bg-transparent text-white "}`,children:j})}),a.jsx(n(),{href:"/about",children:a.jsx("li",{className:`font-normal text-[16px] leading-[19px] cursor-pointer  hover:text-[#145C9B] ${"/about"===s?"text-[#145C9B]":"bg-transparent text-white "}`,children:b})}),a.jsx(n(),{href:"/get-in-touch",children:a.jsx("li",{className:`font-normal text-[16px] leading-[19px] cursor-pointer  hover:text-[#145C9B] ${"/get-in-touch"===s?"text-[#145C9B]":"bg-transparent text-white "}`,children:C})})]}),a.jsx("p",{className:"text-[#CCC9DC] font-normal text-[14px] leading-[17px] mt-[2rem] w-[449px]",children:c})]}),(0,a.jsxs)("div",{className:"",children:[a.jsx("p",{className:"font-bold text-[16px] text-[#CCC9DC] leading-[19px]",children:t("Subscribe to get more info")}),(0,a.jsxs)("form",{action:"https://formspree.io/f/xgegqzod",method:"POST",className:"flex flex-row mt-[1rem]",children:[a.jsx("input",{type:"text",name:"email",placeholder:m,className:"w-[290px] h-[51px] outline outline-[2px] outline-[#324A5F] text-[12px] font-medium text-[#CCC9DC] leading-[14px] bg-transparent px-[1rem] rounded-[4px]"}),a.jsx("button",{type:"submit",className:"bg-[#324A5F] w-[72px] h-[55px] flex items-center justify-center ml-[1rem] rounded-[4px] cursor-pointer mt-[-0.1rem]",children:a.jsx("img",{src:"/images/home/subs-btn.svg",alt:""})})]})]})]}),a.jsx("div",{className:"w-full h-[1.5px] bg-[#324A5F]"}),(0,a.jsxs)("div",{className:"w-[90vw] mx-auto p-[0.5rem] flex justify-between",children:[(0,a.jsxs)("div",{className:"flex flex-row text-[#CCC9DC] text-[14px] font-medium leading-[17px] gap-[0.2rem]",children:[a.jsx("p",{children:"@lifecomradio.co.uk "}),a.jsx("p",{children:"|"}),a.jsx("p",{children:"www.lifecomradio.co.uk"})]}),(0,a.jsxs)("div",{className:"flex flex-row text-[#CCC9DC] text-[14px] font-medium leading-[17px] gap-[0.2rem]",children:[a.jsx("p",{children:"Privacy Policy "}),a.jsx("p",{children:"|"}),a.jsx("p",{children:"Terms & Conditions"})]})]})]})};r()}catch(e){r(e)}})},1962:(e,t,s)=>{"use strict";s.a(e,async(e,r)=>{try{s.d(t,{Z:()=>d});var a=s(997);s(6689);var l=s(1664),i=s.n(l),n=s(9332),o=s(8986),c=s(7987),x=e([o,c]);[o,c]=x.then?(await x)():x;let d=({locale:e})=>{let{t}=(0,c.useTranslation)("home",{lng:e}),s=(0,n.usePathname)(),r=s.substring(3);return(0,a.jsxs)("div",{className:"bg-[#09172E] w-full pt-[2rem] relative md:hidden px-[5vw]",children:[a.jsx("img",{src:"/images/home/radio.png",alt:"",className:"absolute top-0 left-0 right-0 mx-auto"}),a.jsx("p",{className:"text-white font-semibold text-[14px]",children:"Quick Links"}),(0,a.jsxs)("div",{className:"flex flex-row justify-between mt-[2rem]",children:[(0,a.jsxs)("ul",{className:"md:hidden flex flex-col gap-[0.13rem] items-left",children:[a.jsx(i(),{href:"/",locale:e,children:a.jsx("li",{className:`font-medium text-[10px] leading-[19px] cursor-pointer hover:text-[#145C9B] ${"/"===r||3===s.length?"text-[#145C9B]":"bg-transparent text-white "}
      `,children:t("Home")})}),a.jsx(i(),{href:"/explore",locale:e,children:a.jsx("li",{className:`font-medium text-[10px] leading-[19px] cursor-pointer hover:text-[#145C9B]
               ${r.startsWith("/explore")?"text-[#145C9B]":"bg-transparent text-white "}`,children:t("Explore")})}),a.jsx(i(),{href:"/schedule",locale:e,children:a.jsx("li",{className:`font-medium text-[10px] leading-[19px] cursor-pointer  hover:text-[#145C9B] ${"/schedule"===r?"text-[#145C9B]":"bg-transparent text-white "}`,children:t("Schedule")})}),a.jsx(i(),{href:"/about",locale:e,children:a.jsx("li",{className:`font-medium text-[10px] leading-[19px] cursor-pointer  hover:text-[#145C9B] ${"/about"===r?"text-[#145C9B]":"bg-transparent text-white "}`,children:t("About us")})}),a.jsx(i(),{href:"/get-in-touch",locale:e,children:a.jsx("li",{className:`font-medium text-[10px] leading-[19px] cursor-pointer  hover:text-[#145C9B] ${"/get-in-touch"===r?"text-[#145C9B]":"bg-transparent text-white "}`,children:t("Contact")})})]}),(0,a.jsxs)("div",{className:"mt-[0.5rem]",children:[(0,a.jsxs)("div",{className:"flex flex-row gap-[0.3rem] items-end",children:[a.jsx("img",{src:"/images/getintouch/location.png",alt:"",className:"h-[11.3px] w-[8px] mb-[4px]"}),a.jsx("p",{className:"font-medium text-[12px] text-white",children:"Office Address"})]}),a.jsx("p",{className:"font-normal text-[10px] text-[#CCC9DC] mt-0.5rem] ml-[0.7rem] leading-[19px]",children:"22 Cutmore Street "}),a.jsx("p",{className:"font-normal text-[10px] text-[#CCC9DC] mt-[0.3rem] ml-[0.7rem] leading-[19px]",children:"Gravesend Kent"}),a.jsx("p",{className:"font-normal text-[10px] text-[#CCC9DC] mt-[0.3rem] ml-[0.7rem] leading-[19px]",children:" DA11 0PS"})]}),a.jsx("div",{className:"flex flex-row gap-[0.2rem]",children:(0,a.jsxs)("div",{className:"flex flex-col gap-[0.5rem]",children:[(0,a.jsxs)("a",{href:"https://www.facebook.com/Lifecomfm.co.uk/",target:"_blank",rel:"noreferrer",children:[" ",a.jsx("img",{src:"/images/home/facebook.svg",alt:"",className:"cursor-pointer w-[20px] h-[20px]"})," "]}),a.jsx("img",{src:"/images/home/twitter.svg",alt:"",className:"cursor-pointer w-[20px] h-[20px]"}),a.jsx("a",{href:"https://www.instagram.com/lifecom_radioandtelevision/",target:"_blank",rel:"noreferrer",children:a.jsx("img",{src:"/images/home/instagram.svg",alt:"",className:"cursor-pointer w-[20px] h-[20px]"})}),a.jsx("img",{src:"/images/home/linkedin.svg",alt:"",className:"cursor-pointer w-[20px] h-[20px]"})]})})]}),(0,a.jsxs)("div",{className:"w-[90vw] mx-auto p-[0.5rem] flex justify-between mt-[4rem]",children:[a.jsx("div",{className:"flex flex-row text-[#CCC9DC] text-[10px] font-normal leading-[17px] gap-[0.2rem]",children:a.jsx("p",{children:"@lifecomradio.co.uk "})}),(0,a.jsxs)("div",{className:"flex flex-row text-[#CCC9DC] text-[10px] font-normal leading-[17px] gap-[0.2rem]",children:[a.jsx("p",{children:"Privacy Policy "}),a.jsx("p",{children:"|"}),a.jsx("p",{children:"Terms & Conditions"})]})]})]})};r()}catch(e){r(e)}})},7830:(e,t,s)=>{"use strict";s.a(e,async(e,r)=>{try{s.d(t,{Z:()=>d});var a=s(997),l=s(6689),i=s(1664),n=s.n(i),o=s(1163);s(2746);var c=s(7987),x=e([c]);c=(x.then?(await x)():x)[0];let d=({locale:e})=>{let{t}=(0,c.useTranslation)("subscribe",{lng:e}),s=(0,o.useRouter)(),r=s.pathname,[i,x]=(0,l.useState)(!1),d=s.pathname;r&&r.substring(3);let[m,p]=(0,l.useState)(!1),h=[{code:"en",name:"ENG"},{code:"fr",name:"FRA"},{code:"es",name:"ESP"},{code:"it",name:"ITA"}],[u,g]=(0,l.useState)(e);return(0,a.jsxs)("div",{className:"w-full px-[5vw] mx-auto py-[1rem] flex justify-between items-center fixed top-0 left-0 right-0 bg-[#0C1821] z-[10000]",children:[a.jsx("img",{src:"/images/home/logo.svg",alt:"",className:"w-[27px] h-[27px] md:w-[56px] md:h-[56px]"}),(0,a.jsxs)("ul",{className:"hidden md:flex flex-row gap-[1.5rem] items-center",children:[a.jsx(n(),{href:"/",locale:e,children:a.jsx("li",{className:`font-normal text-[16px] leading-[19px] cursor-pointer hover:text-[#145C9B] ${"/"===r||r?.length===3?"text-[#145C9B]":"bg-transparent text-white "}
      `,children:t("Home")})}),a.jsx(n(),{href:"/explore",locale:e,children:a.jsx("li",{className:`font-normal text-[16px] leading-[19px] cursor-pointer hover:text-[#145C9B]
               ${r.startsWith("/explore")?"text-[#145C9B]":"bg-transparent text-white "}`,children:t("Explore")})}),a.jsx(n(),{href:"/schedule",locale:e,children:a.jsx("li",{className:`font-normal text-[16px] leading-[19px] cursor-pointer  hover:text-[#145C9B] ${"/schedule"===r?"text-[#145C9B]":"bg-transparent text-white "}`,children:t("Schedule")})}),a.jsx(n(),{href:"/about",locale:e,children:a.jsx("li",{className:`font-normal text-[16px] leading-[19px] cursor-pointer  hover:text-[#145C9B] ${"/about"===r?"text-[#145C9B]":"bg-transparent text-white "}`,children:t("About us")})}),a.jsx(n(),{href:"/get-in-touch",locale:e,children:a.jsx("li",{className:`font-normal text-[16px] leading-[19px] cursor-pointer  hover:text-[#145C9B] ${"/get-in-touch"===r?"text-[#145C9B]":"bg-transparent text-white "}`,children:t("Contact")})})]}),(0,a.jsxs)("div",{className:"hidden md:flex flex-row gap-[1rem] items-center",children:[a.jsx("img",{src:"/images/home/earth.svg",alt:""}),(0,a.jsxs)("div",{className:"flex  flex-row gap-[0.2rem] items-center",children:[a.jsx("p",{className:"font-medium text-[16px] text-white leading-[19px] cursor-pointer",onClick:()=>p(!m),children:h.find(e=>e.code===u)?.name}),a.jsx("img",{src:"/images/home/caret.svg",className:"cursor-pointer",alt:""}),a.jsx("div",{className:`w-[144px] transition-transform duration-300 ease-in text-white absolute right-1 shadow-[0_2px_2px_0_rgba(80,80,80,0.67)] bg-[#0C1821] top-[80px]    py-4 flex flex-col gap-3 justify-center items-center ${m?"translate-x-0":"translate-x-[100%]"}`,children:h.filter(e=>e.code!==u).map((e,t)=>a.jsx(n(),{href:d,locale:e.code,className:"text-white cursor-pointer",onClick:()=>{g(e.code),p(!1)},children:e.name},t))})]})]}),(0,a.jsxs)("div",{className:"relative md:hidden",children:[a.jsx("img",{src:"/images/home/menubar.svg",alt:"",className:`${i?"md:hidden hidden":"md:hidden block"} cursor-pointer`,onClick:()=>{x(!0)}}),a.jsx("img",{onClick:()=>{x(!1)},src:"/images/explore/close.svg",alt:"",className:`${i?"md:hidden block":"md:hidden hidden"} cursor-pointer`}),i?(0,a.jsxs)("div",{className:"absolute bg-[#081A27] right-0 top-[2rem] w-[150px] flex flex-col",children:[(0,a.jsxs)("div",{onClick:()=>gotoLink("/"),className:"cursor-pointer flex  py-2 pl-[26px] items-center gap-[25px] border border-[#324A5F]",children:[a.jsx("img",{src:"/images/explore/home.svg",alt:""}),a.jsx("span",{className:" text-white text-[10px] leading-3 ",children:"HOME"})]}),(0,a.jsxs)("div",{onClick:()=>gotoLink("/explore"),className:"cursor-pointer flex py-2 pl-[26px] items-center gap-[25px] border border-[#324A5F]",children:[a.jsx("img",{src:"/images/explore/explore-icon.svg",alt:""}),a.jsx("span",{className:" text-white text-[10px] leading-3 ",children:"EXPLORE"})]}),(0,a.jsxs)("div",{onClick:()=>gotoLink("/schedule"),className:"cursor-pointer flex py-2 pl-[26px] items-center gap-[25px] border border-[#324A5F]",children:[a.jsx("img",{src:"/images/explore/schedule.svg",alt:""}),a.jsx("span",{href:"",className:" text-white text-[10px] leading-3 ",children:"SCHEDULE"})]}),(0,a.jsxs)("div",{onClick:()=>gotoLink("/about"),className:"cursor-pointer flex py-2 pl-[26px] items-center gap-[25px] border border-[#324A5F]",children:[a.jsx("img",{src:"/images/explore/about-icon.svg",alt:""}),a.jsx("span",{href:"/",className:" text-white text-[10px] leading-3 ",children:"ABOUT US"})]}),(0,a.jsxs)("div",{onClick:()=>gotoLink("/get-in-touch"),className:"cursor-pointer flex py-2 pl-[26px] items-center gap-[25px] border border-[#324A5F]",children:[a.jsx("img",{src:"/images/explore/contact-icon.svg",alt:""}),a.jsx("span",{className:" text-white text-[10px] leading-3 ",children:"CONTACT"})]})]}):null]})]})};r()}catch(e){r(e)}})},7028:(e,t,s)=>{"use strict";s.d(t,{bN:()=>d,wI:()=>x});var r=s(997),a=s(6689),l=s.n(a),i=s(3543),n=s(4552),o=s(8112);let c=l().createContext(),x=({children:e})=>{let[t,s]=(0,a.useState)([]),[l,x]=(0,a.useState)([]),[d,m]=(0,a.useState)([]);return(0,a.useEffect)(()=>{(0,i.Z)().then(e=>{s(e)}),(0,n._)().then(e=>{x(e)}),(0,o.I)().then(e=>{m(e)})},[]),r.jsx(c.Provider,{value:{articles:t,blogs:l,podcasts:d},children:e})},d=()=>(0,a.useContext)(c)},8986:(e,t,s)=>{"use strict";s.a(e,async(e,t)=>{try{var r=s(2021),a=s(7987),l=s(3847),i=s(6252),n=s(2746),o=s.n(n),c=e([r,a,l,i]);[r,a,l,i]=c.then?(await c)():c,r.default.use(l.default).use(i.default).use(a.initReactI18next).init({fallbackLng:o().defaultLocale,supportedLngs:o().locales,backend:{loadPath:"/locales/{{lng}}/{{ns}}.json"},react:{useSuspense:!1}}),t()}catch(e){t(e)}})},9413:(e,t,s)=>{"use strict";s.a(e,async(e,r)=>{try{s.r(t),s.d(t,{default:()=>d});var a=s(997);s(108);var l=s(7830),i=s(1732),n=s(1962),o=s(7028),c=s(1163),x=e([l,i,n]);function d({Component:e,pageProps:t}){let s=(0,c.useRouter)().locale;return a.jsx("div",{className:"bg-[#0C1821]",children:(0,a.jsxs)(o.wI,{children:[a.jsx(l.Z,{locale:s}),a.jsx(e,{...t}),a.jsx(i.Z,{locale:s}),a.jsx(n.Z,{})]})})}[l,i,n]=x.then?(await x)():x,r()}catch(e){r(e)}})},3543:(e,t,s)=>{"use strict";s.d(t,{Z:()=>l,H:()=>i});let r=`
  query AllArticles {
    articles {
      id
      coverImage {
        url
      }
      createdAt
      description
      id
      readingTime
      updatedAt
      title
      slug
      author {
        ... on Author {
          id
          name
          image {
            id
          }
        }
      }
      content {
        text
      }
    }
  }
`,a=`
  query SingleArticle($slug: String!) {
    article(where: { slug: $slug }) {
      coverImage {
        url
      }
        author {
            ... on Author {
              id
              name
              image {
                id
              }
            }
          }
          content {
            text
            raw
          }
          createdAt
          description
          id
          readingTime
          slug
          title
          updatedAt

    }
}
`,l=async()=>{let e=await fetch("https://api-eu-west-2.hygraph.com/v2/clumsr21f0opz07tbp81bplcp/master",{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({query:r})});return(await e.json()).data.articles},i=async e=>{let t=await fetch("https://api-eu-west-2.hygraph.com/v2/clumsr21f0opz07tbp81bplcp/master",{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({query:a,variables:{slug:e}})});return(await t.json()).data.article}},4552:(e,t,s)=>{"use strict";s.d(t,{_:()=>l,V:()=>i});let r=`
query AllBlogs {
    blogs {
      coverImage {
        url
      }
      title
      slug
      id
    }
  }
  
`,a=`
query SingleBlog($slug: String!){
    blog(where: { slug: $slug }) {
      slug
      title
      id
      updatedAt
      createdAt
      coverImage {
        url
      }
      media {
        url
      }
      content {
        raw
      }
    }
  }
  
`,l=async()=>{let e=await fetch("https://api-eu-west-2.hygraph.com/v2/clumsr21f0opz07tbp81bplcp/master",{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({query:r})});return(await e.json()).data.blogs},i=async e=>{let t=await fetch("https://api-eu-west-2.hygraph.com/v2/clumsr21f0opz07tbp81bplcp/master",{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({query:a,variables:{slug:e}})});return(await t.json()).data.blog}},8112:(e,t,s)=>{"use strict";s.d(t,{I:()=>l,L:()=>i});let r=`
query AllPodcasts {
    podcasts {
        description
        id
        coverImage {
          url
        }
        author {
          ... on Author {
            id
            name
            image {
              id
            }
          }
        }
        slug
        title
      }
  }
  
`,a=`
query SinglePodcast($slug: String!){
    podcast(where: {slug: $slug}) {
        coverImage {
          url
        }
        podcast {
          id
          url
        }
        title
        slug
        description
        epDescription
        createdAt
        duration
      }
  }
  
`,l=async()=>{let e=await fetch("https://api-eu-west-2.hygraph.com/v2/clumsr21f0opz07tbp81bplcp/master",{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({query:r})});return(await e.json()).data.podcasts},i=async e=>{let t=await fetch("https://api-eu-west-2.hygraph.com/v2/clumsr21f0opz07tbp81bplcp/master",{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({query:a,variables:{slug:e}})});return(await t.json()).data.podcast}},108:()=>{}};