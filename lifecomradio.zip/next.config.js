 /** @type {import('next').NextConfig} */


const i18n=require("./i18nConfig")


const nextConfig= {
  i18n,

  // trailingSlash: true,
}

module.exports=nextConfig;