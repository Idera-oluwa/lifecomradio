

// i18nConfig.js
const i18nConfig = {
    locales: ['en', 'fr', 'es', 'it'],
    defaultLocale: 'en',
    // noPrefix:true,
  };
  
  module.exports = i18nConfig;
  